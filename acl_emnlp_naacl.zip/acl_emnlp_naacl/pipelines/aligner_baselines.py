# -*- coding: utf-8 -*-

"""
This file is subject to the terms and conditions defined in
file 'LICENSE', which is part of this source code package. 

author : Kyle Richardson

"""

import os
import sys
import re
import shutil

params = [
    ("--baseline_type","baseline_type","pseudo","str",
     "The type of baseline to carry out [default='']","Polyglot"),
    ("--static_data","static_data","","str",
     "The location and name of data [default='']","Polyglot"),
]

description = {"AlignerBaselines":"Pipeline for running aligner baselines"}

tasks = [
    "setup_data",
    "zubr.RankDecoder",
]

SUFFIX = {
    "pseudo"         : "_pseudo",
    "descriptions"   : None,
    "term"           : "_bow",
}

def setup_data(config):
    """Find the correct data, sets the atraining 

    :param config: the main configuration 
    :raises: ValueError
    """
    suffix = SUFFIX.get(config.baseline_type,-1)
    dname = os.path.basename(config.static_data)
    dirname = os.path.dirname(config.static_data)

    if suffix == -1:
        raise ValueError('Unknown type of data: %s' % suffix)
    if not suffix: suffix = ''
    dname = os.path.basename(config.static_data)
    etrain = config.static_data+"%s.e" % suffix
    ftrain = config.static_data+"%s.f" % suffix
    etest =  config.static_data+"_test.e"
    ftest =  config.static_data+"_test.f"
    evalid = config.static_data+"_val.e"
    fvalid = config.static_data+"_val.f"

    # ## new e train
    netrain = os.path.join(config.dir,dname+".e")
    nftrain = os.path.join(config.dir,dname+".f")

    #copy the data over
    shutil.copy(etrain,netrain)
    shutil.copy(ftrain,nftrain)

    ## copy others
    shutil.copy(etest,config.dir)
    shutil.copy(ftest,config.dir)
    shutil.copy(evalid,config.dir)
    shutil.copy(fvalid,config.dir)

    ## point to the aligner training data
    config.atraining = os.path.join(config.dir,dname)
    ## point to the rank file
    rank_file = os.path.join(dirname,"rank_list.txt")
    new_rank = os.path.join(config.dir,"rank_list.txt")
    shutil.copy(rank_file,config.dir)
    config.rfile = new_rank

    if config.baseline_type == "term":
        config.termbaseline = True
