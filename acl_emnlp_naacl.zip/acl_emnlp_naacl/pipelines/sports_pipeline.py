import os
import shutil
import codecs
import re
from shutil import copytree,copy

curr_path = os.path.abspath(os.path.dirname(__file__))
data_path = os.path.abspath(os.path.join(curr_path,'../other_data'))
s_path = os.path.abspath(os.path.join(curr_path,'../other_data/sportscaster'))

params = [
    ("--game","game","0_1_2","str",
     "The particular sports game to use [default='']","SportsRun"),
]

description = {"SportsRun" : "settings for running the sportscaster reranker"}

tasks = [
    "setup_data",
    "zubr.wrapper.foma",
    "add_graph",
    "zubr.GraphDecoder",
    "zubr.Dataset",          ## make a dataset
    "zubr.FeatureExtractor", ## make the feature extractor
    "zubr.Optimizer",        ## train a reranker model
]

teams   = set(["team","purple_","pink_"])
colors  = set(["purple@@","pink@@"])
plays   = set(["play@","mode@r","free_","corner_","kick_","play@@","in_","goal_","on","offside_","off_","play_"])
passing = set(["pass@r","bad@@","pass","kick@r"])
numbers = set([str(n) for n in range(12)])
latent  = set(["player@l","ball@l","from@l"])
turns = set(["ball@@","turn@@","stopped@r","over@r","steal@r","block@r"])
defense = set(["block@r","defense@r",""])

GRAMMAR = """

rep -> turns 
rep -> contact player
rep -> mode team

contact -> contact player 
contact -> cevent player 
contact -> def_event player 
player -> team number
number -> 4
team   -> 1
cevent -> 3
teams  -> 8
teams  -> teams teams
def_event -> 7
mode   -> plays
mode   -> plays plays 
plays  -> 2
turns  -> 6
latent -> 5
turns  -> turns latent


"""

def add_graph(config):
    config.graph = os.path.join(config.dir,"graph.att")

def swap_data(config):
    ebow = "%s_bow.e" % (config.atraining)
    fbow = "%s_bow.f" % (config.atraining)
    etrain = "%s.e" % (config.atraining)
    ftrain = "%s.f" % (config.atraining)
    copy(ebow,etrain)
    copy(fbow,ftrain)

def __make_trees(wdir,path,tree_path,grammar_path,rfile):
    tree_map = {}
    
    with codecs.open(path,encoding='utf-8') as my_data:
        with codecs.open(tree_path,'w',encoding='utf-8') as my_trees: 
            for line in my_data:
                line = line.strip()
                trees = []
                words = line.split()
                for word in words:
                    if word in colors:    idx = '1'
                    elif word in plays:   idx = '2'
                    elif word in passing: idx = '3'
                    elif word in numbers: idx = '4'
                    elif word in latent:  idx = '5'
                    elif word in turns:   idx = '6'
                    elif word in defense: idx = '7'
                    elif word in teams:   idx = '8'
                    trees.append(idx)

                final = "%s\t%s" % (' '.join(trees),5)
                print >>my_trees,"%s\t%s" % (' '.join(trees),5)
                tree_map[line] = final
                
    ## make a little grammar
    with codecs.open(grammar_path,'w',encoding='utf-8') as my_grammar:
        print >>my_grammar,GRAMMAR

    ## add rank trees
    rank_trees = os.path.join(wdir,"rank_list.tree")
    with codecs.open(rfile,encoding='utf-8') as my_ranks:
        with codecs.open(rank_trees,'w',encoding='utf-8') as my_trees: 
            for line in my_ranks:
                line = line.strip()
                trees = []
                words = line.split()
                for word in words:
                    if word in colors:    idx = '1'
                    elif word in plays:   idx = '2'
                    elif word in passing: idx = '3'
                    elif word in numbers: idx = '4'
                    elif word in latent:  idx = '5'
                    elif word in turns:   idx = '6'
                    elif word in defense: idx = '7'
                    elif word in teams:   idx = '8'
                    trees.append(idx)
                print >>my_trees,"%s\t%s" % (' '.join(trees),5)

                
                        
        
def setup_data(config):

    ##
    gdir = os.path.join(s_path,"games_%s" % config.game)

    ## training data
    epseudo = os.path.join(gdir,"sports.e")
    fpseudo = os.path.join(gdir,"sports.f")
    ebow = os.path.join(gdir,"sports_bow.e")
    fbow = os.path.join(gdir,"sports_bow.f")
    emain = os.path.join(config.dir,"sports.e")
    fmain = os.path.join(config.dir,"sports.f")
    shutil.copy(epseudo,emain)
    shutil.copy(fpseudo,fmain)
    shutil.copy(ebow,config.dir)
    shutil.copy(fbow,config.dir)


    ## testing data
    etest = os.path.join(gdir,"sports_test.e")
    ftest = os.path.join(gdir,"sports_test.f")
    shutil.copy(etest,config.dir)
    shutil.copy(ftest,config.dir)

    ## validation
    evalid = os.path.join(gdir,"sports_val.e")
    fvalid = os.path.join(gdir,"sports_val.f")
    shutil.copy(evalid,config.dir)
    shutil.copy(fvalid,config.dir)

    config.atraining = os.path.join(config.dir,"sports")

    ## copy the rerank data
    shutil.copy(os.path.join(gdir,"rank_list.txt"),config.dir)
    config.rfile = os.path.join(gdir,"rank_list.txt")

    ## make tree data
    __make_trees(config.dir,
                     fbow,os.path.join(config.dir,"sports.tree"),
                     os.path.join(config.dir,"grammar.txt"),
                     config.rfile
                     )

    ## settings 
    config.rmodel = 'aligner'
    config.encoding = 'utf-8'
    config.extract_phrases = True
    config.extract_hiero   = True
    config.extractor       = 'graph'
    config.eval_val        = True
    config.store_feat      = True
    config.pipeline_backup = True
    config.print_table     = True
    config.decode_all      = True
    config.aheuristic      = 'grow-diag'
