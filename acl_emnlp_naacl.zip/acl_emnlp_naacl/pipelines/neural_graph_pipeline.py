import os
import re
from shutil import copytree,copy
import logging
import codecs
import subprocess

params = [
    ("--wdir","wdir",'',"str",
     "The working directory [default='']","NeuralRunner"),
    ("--name","name",'',"str",
     "The name of the dataset [default='']","NeuralRunner"),
    ("--bow","bow",False,"bool",
     "Use the smaller _bow training data [default=False]","NeuralRunner"),
    ("--make_subword","make_subword",False,"bool",
     "Use the subword representations for english side [default=False]","NeuralRunner"),
    ("--make_sem_subword","make_sem_subword",False,"bool",
     "Use the subword representations for english side [default=False]","NeuralRunner"),     
    ("--add_extra","add_extra",False,"bool",
     "Add extra data to the neural parallel training data [default=False]","NeuralRunner"),
    ("--num_symbols","num_symbols",1000,"int",
     "The number of symbols for the subword builder [default=False]","NeuralRunner"),
    ("--trans","trans",False,"bool",
     "Use transliterated version of data (if available) [default=False]","NeuralRunner"),
    ("--mixed","mixed",False,"bool",
     "Use mixed data (if available) [default=False]","NeuralRunner"),
    ("--add_hiero","add_hiero",False,"bool",
     "Add hiero rules to training (if available) [default=False]","NeuralRunner"),
    ("--double_data","double_data",False,"bool",
     "Double the data [default=False]","NeuralRunner"),     
]

    
description = {"NeuralRunner" : "settings for running neural model"}

tasks = [
    "setup_data",
    "zubr.neural.run"
]

script_logger = logging.getLogger("neural_model")


def __extra_pairs(pseudo,extra,new_e,new_f):
    """Extract single occurrences of the extra data to use for training data

    :param pseudo: the pseudo lexicon entries 
    :param extra: the extra parallel pairs 
    """
    pairs = set()
    
    if os.path.isfile(pseudo):
        with codecs.open(pseudo,encoding='utf-8') as lex:
            for line in lex:
                line = line.strip()
                try: 
                    w1,w2 = line.split('\t')
                    w1 = w1.strip().lower()
                    w2 = w2.strip().lower()
                    ## don't add too much 
                    if w1 != w2: continue
                    pairs.add((w2,w1))
                except: pass 
    if extra:
        with codecs.open(extra,encoding='utf-8') as more:
            for line in more:
                line = line.strip()
                sem,en = line.split('\t')
                sem = sem.strip().lower()
                en = en.strip().lower()
                pairs.add((en,sem))

    ## add to the training data 
    if pairs:
        with codecs.open(new_e,'a',encoding='utf-8') as english:
            with codecs.open(new_f,'a',encoding='utf-8') as foreign:
                for (en,sem) in pairs:
                    print >>english,en.strip()
                    print >>foreign,sem.strip()

                    
def setup_data(config):
    """Make sure data directory exists, ...

    :param config: the global configuration 
    :rtype: None
    """
    ## check that working directory is specified and exists 
    if config.wdir is None:
        exit('Please specify data directory! exiting...')
    if not os.path.isdir(config.wdir):
        exit('Cannot find the specified working directory! exiting...')
    if config.name is None:
        exit('Please specify the name of the data! exiting...')

    ## copy over the held out datasets 
    held_out = os.path.join(config.wdir,"held_out")
    copytree(held_out,os.path.join(config.dir,"held_out"))
    ## copy over the train stuff
    train_dir = os.path.join(config.wdir,"train")
    copytree(train_dir,os.path.join(config.dir,"train"))
    ## copy over the trains
    rank_dir = os.path.join(config.wdir,"ranks")
    copytree(rank_dir,os.path.join(config.dir,"ranks"))

    ## use the subword representations by default

    ## nl 
    traine = os.path.join(config.dir,"train/polyglot_seg.e")
    trainbowe = os.path.join(config.dir,"train/polyglot_bow_seg.e")
    teste = os.path.join(config.dir,"held_out/polyglot_test_seg.e")
    valide = os.path.join(config.dir,"held_out/polyglot_val_seg.e")
    ## sem side
    trainf = os.path.join(config.dir,"train/polyglot_seg.f")
    trainbowf = os.path.join(config.dir,"train/polyglot_bow_seg.f")
    traint = os.path.join(config.dir,"train/polyglot_seg.tree")
    testf = os.path.join(config.dir,"held_out/polyglot_test_seg.f")
    validf = os.path.join(config.dir,"held_out/polyglot_val_seg.f")
    globalr = os.path.join(config.dir,"ranks/global_rank_list_seg.txt")
    globalt = os.path.join(config.dir,"ranks/rank_list_seg.tree")
    graph_path = os.path.join(config.wdir,"graphs/seg_graph.att")

    ## RANKS
    ## copy the rank file
    copy(globalr,os.path.join(config.dir,"rank_list.txt"))
    copy(globalt,os.path.join(config.dir,"rank_list.tree"))
    config.rfile = os.path.join(config.dir,"rank_list.txt")

    ## LANGUAGE
    ## 
    trainl = os.path.join(config.dir,"train/polyglot.language")
    testl = os.path.join(config.dir,"held_out/polyglot_test.language")
    validl = os.path.join(config.dir,"held_out/polyglot_val.language")

    ## MAIN DATA 
    ## copy over
    #copy(traine,os.path.join(config.dir,"polyglot.e"))
    #copy(trainf,os.path.join(config.dir,"polyglot.f"))
    copy(traint,os.path.join(config.dir,"polyglot.tree"))
    copy(trainbowe,os.path.join(config.dir,"polyglot.e"))
    copy(trainbowf,os.path.join(config.dir,"polyglot.f"))
    
    copy(teste,os.path.join(config.dir,"polyglot_test.e"))
    copy(testf,os.path.join(config.dir,"polyglot_test.f"))
    copy(valide,os.path.join(config.dir,"polyglot_val.e"))
    copy(validf,os.path.join(config.dir,"polyglot_val.f"))

    ## language copies
    copy(trainl,config.dir)    
    copy(validl,config.dir)
    copy(testl,config.dir)

    ## change atraining pointer
    config.atraining = os.path.join(config.dir,"polyglot")

    ## graph
    new_gloc = os.path.join(config.dir,"graph.att")
    copy(graph_path,new_gloc)
    config.graph = new_gloc

    ## decode the data
    config.decode_data = True
    config.name = "polyglot"

    ## set the atraining settings 
    config.atraining = os.path.join(config.dir,config.name)

    ## additional global adjustments to configuration 
    config.amax = 250
    config.extract_phrases = False 
    config.extract_hiero = False

    ##
    script_logger.info('Number of jobs to run (if concurrent): %d' % config.num_jobs)
