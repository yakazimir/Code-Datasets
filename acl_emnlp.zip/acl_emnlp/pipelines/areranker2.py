# -*- coding: utf-8 -*-

"""
This file is subject to the terms and conditions defined in
file 'LICENSE', which is part of this source code package. 

author : Kyle Richardson

Pipeline script for running a reranker on zubr models

- This script assumes that you have data in a directory with the following
structure:

    data_dir/
        name_base.e      ## english training data for training base model
        name_base.f      ## sem training data for base model
        name_rerank.e    ## english training data for reranker (might be identical to base data)
        name_rerank.f    ## sem training data for reranker (might be identical to base data)
        rank_list.txt    ## a list of outputs to rank
        name_test.e      ## english testing data (optional)
        name_test.f      ## sem testing data     (optional)
        name_valid.e     ## english validation data (optional)
        name_valid.f     ## sem validation data (optional)
        descriptions.txt ## additional symbol/text pairs (optional)
        rank_list.tree   ## tree positions for reranker list (optional)
        abstract.txt     ## abstract symbol classes (optional)
        rank_list_class.txt ### abstract classes of functions (optional)
        
-- This pipeline script will train a base aligner model, construct the
reranker datasets, construct a feature extractor for the reranker, train
and optimize a reranker using training data, and evaluate on a test set

"""

import os
from zubr.util.decor import catchPipelineError
from shutil import copytree,copy

params = [
    ("--filter_phrases","filter_phrases",False,"bool",
     "filter the phrase table [default=True]","RerankerScript"),
    ("--no_extra","no_extra",False,"bool",
     "train model without extra data (only pseudolex) [default=True]","RerankerScript")
]

description = {"RerankerScript":'settings for the reranker (glue) script'}

## pipeline of tasks

tasks = [
    "setup_pipeline",           ## set up data
    "zubr.SymmetricAlignment",    ## train aligner (or base model)
    "swap_data",                ## swap in training data for reranker 
    "zubr.Dataset",             ## build dataset for reranker
    "zubr.FeatureExtractor",    ## build feature extractor
    "zubr.Optimizer",           ## reranker optimizer
    ## this is commented out to run experiment on french
    "first_selection",         
    "zubr.FeatureSelection",    ## perform feature selection pruning out individual features that cuase problems
    "second_selection",
    "zubr.FeatureSelection",
    "before_retrain1",
    "zubr.Optimizer",
    "before_retrain2",
    "zubr.Optimizer",
    # ## very important
    "after_retrain",
]

def after_retrain(config):
    config.retrain_temp = False
    config.retrain_indv = False

def before_retrain1(config):
    config.retrain_temp = True
    config.model_loc = os.path.join(config.dir,"select_temp")
    
def before_retrain2(config):
    config.retrain_indv = True
    config.retrain_temp = False 
    config.model_loc = os.path.join(config.dir,"select_indv")
    
def first_selection(config):
    """Makes sure that path for feature selection is setup correctly 

    :param config: configuration 
    """
    config.model_dir = config.dir
    config.test_individual = True
    #config.test_templates = True

def second_selection(config):
    """Second round of feature selection will trying to test templates

    :param config: the configuration
    """
    config.test_individual = False
    config.test_templates  = True

def third_selection(config):
    """The last feature selection

    :param config: the configuration 
    """
    config.test_individual = False
    config.test_templates  = True 
    config.model_dir = os.path.join(config.model_dir,"select_indv")

def copy_data(config):
    """copy the main data over to working directory, also set
    up the correct training data for base model

    -- assumes that data has file name_base.e,name_base.f 

    :param config: main zubr configuration object
    :type config: zubr.util.config.ConfigAttrs
    """
    data_dir = os.path.dirname(config.atraining)
    new = os.path.join(config.dir,"orig_data")
    name = config.atraining.split('/')[-1]

    
    if config.dir != data_dir or not os.isdir(new):
        copytree(data_dir,new)
        config.atraining = os.path.join(new,name)
        config.rfile = os.path.join(config.dir,"orig_data/rank_list.txt")

    if not config.no_extra:
        basee = "%s_base.e" % config.atraining
        basef = "%s_base.f" % config.atraining
    else:
        basee = "%s_pseudo.e" % config.atraining
        basef = "%s_pseudo.f" % config.atraining

    etrain = "%s.e" % config.atraining
    ftrain = "%s.f" % config.atraining
    copy(basee,etrain)
    copy(basef,ftrain)

    hiero_rules = os.path.join(data_dir,"hiero_rules.txt")
    glue_rules  = os.path.join(data_dir,"grammar.txt")

    if not os.path.isfile(hiero_rules):
        raise ValueError('Missing hiero rules!')
    if not os.path.isfile(glue_rules):
        raise ValueError('Missing grammar rules!')

    config.hierogrammar = hiero_rules
    config.gluegrammar = glue_rules
    
    if config.hierogrammar and os.path.isfile(config.hierogrammar):
        hiero_loc = os.path.join(config.dir,"hiero.txt")
        copy(config.hierogrammar,hiero_loc)

    if config.gluegrammar and os.path.isfile(config.gluegrammar):
        glue_loc = os.path.join(config.dir,"grammar.txt")
        copy(config.gluegrammar,glue_loc)


def swap_data(config):
    """change to ranking data to files with name_rank.{e,f}"""

    reranke = "%s_rerank.e" % config.atraining
    rerankf = "%s_rerank.f" % config.atraining
    etrain = "%s.e" % config.atraining
    ftrain = "%s.f" % config.atraining
    copy(reranke,etrain)
    copy(rerankf,ftrain)

    ## connect up the hierarchical grammar rules and glue grammar rules

@catchPipelineError()
def setup_pipeline(config):
    """set up the base model for the reranker

    :param config: main config object for experiment and related utilities
    :type config: zubr.util.config.ConfigAttrs
    :raises ValueError: raises when model is selected that is not supported
    :rtype: None 
    """
    config.dump_models = True
    config.cleanup = True
    config.rmodel = 'symaligner'

    ## do not keep copy of 
    config.save_phrases = False
    config.print_table = True    
    copy_data(config)
