import os
import subprocess
import shutil
from shutil import copytree,copy

py_data = os.path.join(os.path.dirname(os.path.abspath(__file__)),"../other_data/py27")

params = [
     ("--py_lang","py_lang","","str",
     "The language to run [default='']","PySingle"),
]

description = {"PySingle" : "Processing pipeline for rerunning the py27 reranker experiments"}

tasks = [
    "copy_data",
    "zubr.SymmetricAlignment",
    "swap_data",
    "zubr.Dataset",
    "zubr.FeatureExtractor",
    "zubr.Optimizer",
    "before_interface",
    "zubr.QueryInterface",
]


def swap_data(config):
    """change to ranking data to files with name_rank.{e,f}

    :param config: the main configuration object 
    """
    reranke = "%s_bow.e" % config.atraining
    rerankf = "%s_bow.f" % config.atraining
    etrain = "%s.e" % config.atraining
    ftrain = "%s.f" % config.atraining
    copy(reranke,etrain)
    copy(rerankf,ftrain)

def copy_data(config):
    """Copy the data from the py27 backup  

    :param config: the main configuration 
    """
    ## check that python project is specified 
    if not config.py_lang or not isinstance(config.py_lang,basestring):
        exit('Please specify a python project to run!')

    ## check that project exists 
    project_ext = os.path.join(py_data,config.py_lang)
    if not os.path.isdir(project_ext):
        exit('Unknown python project: name=%s, ext=%s' % (config.py_lang,project_ext))


    ## copy over the original files
    os.system("cp %s %s" % (os.path.join(project_ext,"*.e"),config.dir))
    os.system("cp %s %s" % (os.path.join(project_ext,"*.f"),config.dir))
    os.system("cp %s %s" % (os.path.join(project_ext,"*rank_list*"),config.dir))
    os.system("cp %s %s" % (os.path.join(project_ext,"*grammar*"),config.dir))
    os.system("cp %s %s" % (os.path.join(project_ext,"*hiero*"),config.dir))
    os.system("cp %s %s" % (os.path.join(project_ext,"descriptions.txt"),config.dir))
    os.system("cp %s %s" % (os.path.join(project_ext,"*.tree"),config.dir))
    os.system("cp %s %s" % (os.path.join(project_ext,"*extra_pairs*"),config.dir))

    ## copy over the original data directory (just in case) 
    os.system("cp -r %s %s" % (os.path.join(project_ext,"orig_data"),config.dir))

    ## swap the main data with the {name}_orig.{e,f} data
    e_main = os.path.join(config.dir,"data.e")
    f_main = os.path.join(config.dir,"data.f")
    e_orig = os.path.join(config.dir,"data_orig.e")
    f_orig = os.path.join(config.dir,"data_orig.f")

    ## reset the correct training data
    shutil.copy(e_orig,e_main)
    shutil.copy(f_orig,f_main)

    ## set the aligner training path
    config.atraining = os.path.join(config.dir,"data")
    config.rfile     = os.path.join(config.dir,"rank_list.txt")

    ## generic configuration settings
    config.extract_phrases = True
    config.print_table     = True
    config.rmodel          = 'symaligner'
    config.cleanup         = True
    config.dump_models     = True
    config.hierogrammar = os.path.join(config.dir,"hiero_rules.txt")
    config.gluegrammar  = os.path.join(config.dir,"grammar.txt")

def before_interface(config):
    ## point to the built model for building a query interface 
    config.qmodel = os.path.join(config.dir,"model")
