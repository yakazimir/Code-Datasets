import os
import traceback
import shutil
import logging
from shutil import copytree,copy

params = [
    ("--lang_blocks","lang_blocks","","str",
     "Languages to block [default='']","Polyglot"),
    ("--pdata","pdata","","str",
     "The target polyglot data [default='']","Polyglot"),
    ("--small","small",False,"bool",
     "transliterate all data to simpler 8bit representation [default=False]","Polyglot"),
    ("--sem_sub_word","sem_sub_word",False,"bool",
     "Use BPE for segmenting semantic side [default=False]","Polyglot"),
    ("--sub_word","sub_word",False,"bool",
     "Using subword segmentation method [default=False]","Polyglot"),
    ("--new_ranks","new_ranks",False,"bool",
     "Compute new ranks from scratch [default=False]","Polyglot"),
    ("--remove_on_success","remove_on_success",True,"bool",
     "Remove the working directory on success [default=True]","Polyglot"),
]

script_logger = logging.getLogger('zubr.experiments.polyglot_model')

description = {"Polyglot" : "training/running polyglot models"}

tasks = [
    "set_config",
    "create_dataset",
    "setup_storage",
    "zubr.GraphDecoder",
    "after_decoder",
    "swap_data",
    "zubr.Dataset",
    "zubr.FeatureExtractor",
    "zubr.Optimizer",
]

def swap_data(config):
    """Swap in the correct data for the reranker """
    ebow = "%s_bow.e" % (config.atraining)
    fbow = "%s_bow.f" % (config.atraining)
    etrain = "%s.e" % (config.atraining)
    ftrain = "%s.f" % (config.atraining)

    ### keep a copy of the decoder data 
    copy(etrain,os.path.join(config.dir,"old_train.e"))
    copy(ftrain,os.path.join(config.dir,"old_train.f"))

    ## switch over to the bow data
    copy(ebow,etrain)
    copy(fbow,ftrain)

def after_decoder(config):
    """Run after the decoder is done, exits if point is to build ranks

    :param config: the configuration instance 
    """
    ## storage positions
    tset = config.eval_set
    oset = 'valid' if tset != 'valid' else 'train'
    
    if config.sub_word and config.sem_sub_word:
        rank_out = os.path.join(config.pdata,"storage/%s_storage_seg_seg.npz" % tset)
        txt_out = os.path.join(config.pdata,"storage/%s_ranks_seg_seg.txt" % tset)
        results_out = os.path.join(config.pdata,"storage/%s_rank_results_seg_seg.txt" % tset)
        ## second
        orank_out = os.path.join(config.pdata,"storage/%s_storage_seg_seg.npz" % oset)
        otxt_out = os.path.join(config.pdata,"storage/%s_ranks_seg_seg.txt" % oset)
        oresults_out = os.path.join(config.pdata,"storage/%s_rank_results_seg_seg.txt" % oset)

    elif config.sub_word:
        rank_out = os.path.join(config.pdata,"storage/%s_storage_seg.npz" % tset)
        txt_out = os.path.join(config.pdata,"storage/%s_ranks_seg.txt" % tset)
        results_out = os.path.join(config.pdata,"storage/%s_rank_results_seg.txt" % tset)
        ## second
        orank_out = os.path.join(config.pdata,"storage/%s_storage_seg.npz" % oset)
        otxt_out = os.path.join(config.pdata,"storage/%s_ranks_seg.txt" % oset)
        oresults_out = os.path.join(config.pdata,"storage/%s_rank_results_seg.txt" % oset)

    else:
        rank_out = os.path.join(config.pdata,"storage/%s_storage.npz" % tset)
        txt_out = os.path.join(config.pdata,"storage/%s_ranks.txt" % tset)
        results_out = os.path.join(config.pdata,"storage/%s_rank_results.txt" % tset)
        ## second
        orank_out = os.path.join(config.pdata,"storage/%s_storage.npz" % oset)
        otxt_out = os.path.join(config.pdata,"storage/%s_ranks.txt" % oset)
        oresults_out = os.path.join(config.pdata,"storage/%s_rank_results.txt" % oset)

    ## new ranks created?
    if config.new_ranks:
        ranks = os.path.join(config.dir,"%s_storage.npz" % tset)
        txt_ranks = os.path.join(config.dir,"ranks.txt")
        results = os.path.join(config.dir,"rank_results.txt")
        
        ## copy into data file
        if os.path.isfile(rank_out):    os.remove(rank_out)
        if os.path.isfile(txt_out):     os.remove(txt_out)
        if os.path.isfile(results_out): os.remove(results_out)

        ### make a new file
        shutil.copy(ranks,rank_out)
        shutil.copy(txt_ranks,txt_out)
        shutil.copy(results,results_out)

        ## remove the working directory (free up space)
        #if config.remove_on_success: shutil.rmtree(config.dir)
        exit('Finished decoding, exiting pipeline prematurely....')

    ### copy over the rank stuff

    try: 
        ## copy over the rank items to the working directory 
        shutil.copy(rank_out,os.path.join(config.dir,"%s_storage.npz" % tset))
        shutil.copy(orank_out,os.path.join(config.dir,"%s_storage.npz" % oset))
        shutil.copy(txt_out,os.path.join(config.dir,"%s_ranks.txt" % tset))
        shutil.copy(otxt_out,os.path.join(config.dir,"%s_ranks.txt" % oset))

        ## set the pointers
        config.train_ranks = os.path.join(config.dir,"train_ranks.txt")
        config.valid_ranks = os.path.join(config.dir,"valid_ranks.txt")
        
    except Exception,e:
        script_logger.error(e,exc_info=True)
        exit('Error copying over the rank data: %s' % e)


def set_config(config):
    """Setup the configuration with default settings for polyglot models 

    :param config: the main/global configuration instance 
    :rtype: None 
    """
    config.pseudolex       = True
    config.decoder         = 'polyglot'
    config.rfile           = True
    config.lower           = True
    config.encoding        = 'utf-8'
    config.rmodel          = 'aligner'
    config.ispolyglot      = True
    config.pipeline_backup = True
    config.store_feat      = True
    config.eval_val        = True 

    ## grab phrases
    if not config.new_ranks: 
        config.extract_phrases = True
        config.print_table     = True
        config.extract_hiero   = True

    ## max length (Set this to be pretty big)
    config.amax = 250

    ## graph extractor...?
    config.extractor = "graph"

    ## make sure that the polyglot model is selected
    if 'poly' not in config.decoder_type: 
        config.decoder_type = "polyglot"

def create_dataset(config):
    """Setup all the data needed to run"""
    if not os.path.isdir(config.pdata):
        exit('Please specify the polyglot dataset...')

    ### COPY OVER THE MAIN DATA INTO WDIR 
        
    ## copy over the held out stuff
    held_out = os.path.join(config.pdata,"held_out")
    copytree(held_out,os.path.join(config.dir,"held_out"))
    ## copy over the train stuff
    train_dir = os.path.join(config.pdata,"train")
    copytree(train_dir,os.path.join(config.dir,"train"))
    ## copy over the trains
    rank_dir = os.path.join(config.pdata,"ranks")
    copytree(rank_dir,os.path.join(config.dir,"ranks"))
    ## grammar
    grammar_dir = os.path.join(config.pdata,"graphs/grammar.txt")
    ngrammar_dir = os.path.join(config.dir,"grammar.txt")
    copy(grammar_dir,ngrammar_dir)
    config.glue = ngrammar_dir

    ## nl stuff
    ########################################
    ########################################
    descriptions = os.path.join(config.pdata,"descriptions")
    
    if not config.sub_word: 
        traine = os.path.join(config.dir,"train/polyglot.e")
        trainbowe = os.path.join(config.dir,"train/polyglot_bow.e")
        teste = os.path.join(config.dir,"held_out/polyglot_test.e")
        valide = os.path.join(config.dir,"held_out/polyglot_val.e")
    else:
        traine = os.path.join(config.dir,"train/polyglot_seg.e")
        trainbowe = os.path.join(config.dir,"train/polyglot_bow_seg.e")
        teste = os.path.join(config.dir,"held_out/polyglot_test_seg.e")
        valide = os.path.join(config.dir,"held_out/polyglot_val_seg.e")
        descriptions += "_seg"

    ## sem stuff
    ########################################
    ########################################
    
    if not config.sem_sub_word:
        # train 
        trainf = os.path.join(config.dir,"train/polyglot.f")
        trainbowf = os.path.join(config.dir,"train/polyglot_bow.f")
        traint = os.path.join(config.dir,"train/polyglot.tree")
        # test
        testf = os.path.join(config.dir,"held_out/polyglot_test.f")        
        # valid
        validf = os.path.join(config.dir,"held_out/polyglot_val.f")
        ## rank 
        globalr = os.path.join(config.dir,"ranks/global_rank_list.txt")
        globalt = os.path.join(config.dir,"ranks/rank_list.tree")
        ## graph
        graph_path = os.path.join(config.pdata,"graphs/graph.att")

    else:
        trainf = os.path.join(config.dir,"train/polyglot_seg.f")
        trainbowf = os.path.join(config.dir,"train/polyglot_bow_seg.f")
        traint = os.path.join(config.dir,"train/polyglot_seg.tree")
        # test
        testf = os.path.join(config.dir,"held_out/polyglot_test_seg.f")
        # valid
        validf = os.path.join(config.dir,"held_out/polyglot_val_seg.f")
        ## ranks
        globalr = os.path.join(config.dir,"ranks/global_rank_list_seg.txt")
        globalt = os.path.join(config.dir,"ranks/rank_list_seg.tree")
        ## graph
        graph_path = os.path.join(config.pdata,"graphs/seg_graph.att")
        descriptions += "_seg"

    ## description file 
    descriptions += ".txt"
    try: 
        shutil.copy(descriptions,os.path.join(config.dir,"descriptions.txt"))
    except:
        script_logger.warning('Cannot find the description file: %s' % descriptions)

    ## RANKS
    ## copy the rank file
    shutil.copy(globalr,os.path.join(config.dir,"rank_list.txt"))
    shutil.copy(globalt,os.path.join(config.dir,"rank_list.tree"))
    config.rfile = os.path.join(config.dir,"rank_list.txt")

    ## LANGUAGE
    ## 
    trainl = os.path.join(config.dir,"train/polyglot.language")
    testl = os.path.join(config.dir,"held_out/polyglot_test.language")
    validl = os.path.join(config.dir,"held_out/polyglot_val.language")

    ## MAIN DATA 
    ## copy over
    shutil.copy(traine,os.path.join(config.dir,"polyglot.e"))
    shutil.copy(trainf,os.path.join(config.dir,"polyglot.f"))
    shutil.copy(traint,os.path.join(config.dir,"polyglot.tree"))
    shutil.copy(trainbowe,os.path.join(config.dir,"polyglot_bow.e"))
    shutil.copy(trainbowf,os.path.join(config.dir,"polyglot_bow.f"))
    
    shutil.copy(teste,os.path.join(config.dir,"polyglot_test.e"))
    shutil.copy(testf,os.path.join(config.dir,"polyglot_test.f"))
    shutil.copy(valide,os.path.join(config.dir,"polyglot_val.e"))
    shutil.copy(validf,os.path.join(config.dir,"polyglot_val.f"))

    ## language copies
    shutil.copy(trainl,config.dir)    
    shutil.copy(validl,config.dir)
    shutil.copy(testl,config.dir)

    ## change atraining pointer
    config.atraining = os.path.join(config.dir,"polyglot")

    ## graph
    new_gloc = os.path.join(config.dir,"graph.att")
    shutil.copy(graph_path,new_gloc)
    config.graph = new_gloc

    ## decode the data? 
    if config.new_ranks: config.decode_data = True
    else: config.decode_data = False

def setup_storage(config):
    """Make sure that the storage items are being used if specific

    :param config: the main configuration 
    """
    ### figure out the type of 
    if config.sub_word and config.sem_sub_word:
        train_storage = os.path.join(config.pdata,"storage/train_storage_seg_seg.npz")
        test_storage  = os.path.join(config.pdata,"storage/test_storage_seg_seg.npz")
        valid_storage = os.path.join(config.pdata,"storage/valid_storage_seg_seg.npz")
    elif config.sub_word:
        train_storage = os.path.join(config.pdata,"storage/train_storage_seg.npz")
        test_storage  = os.path.join(config.pdata,"storage/test_storage_seg.npz")
        valid_storage = os.path.join(config.pdata,"storage/valid_storage_seg.npz")
    else:
        train_storage = os.path.join(config.pdata,"storage/train_storage.npz")
        test_storage  = os.path.join(config.pdata,"storage/test_storage.npz")
        valid_storage = os.path.join(config.pdata,"storage/valid_storage.npz")
