# -*- coding: utf-8 -*-

import os
import shutil
import codecs
import re
from shutil import copytree,copy

curr_path = os.path.abspath(os.path.dirname(__file__))
data_path = os.path.abspath(os.path.join(curr_path,'../other_data/SP/geoquery/'))
geo_path = os.path.abspath(os.path.join(curr_path,'../other_data/geoquery'))

params = [
     ("--glang","glang","en","str",
     "The version/language of geoquery to use [default='']","GeoQueryRun"),
    ("--class_file","class_file","","str",
     "The abstract class file [default='']","GeoQueryRun"),
    ("--new_ranks","new_ranks",False,"bool",
     "Compute new ranks [default=False]","GeoQueryRun"),
    ("--mixed","mixed",False,"bool",
     "Evaluate on the mixed language [default=False]","GeoQueryRun")
]

description = {"GeoQueryRun" : "settings for running geoquery"}

tasks = [
    "setup_data",
    "zubr.wrapper.foma",     ## check that the graph is correct
    "make_ranklist",         ## make the rank list from path text file    
    "add_graph",             ## check that the graph path is specified 
    "zubr.GraphDecoder",     ## use the decoder to find ranks
    "swap_data",
    "zubr.Dataset",          ## make a dataset
    "zubr.FeatureExtractor", ## make the feature extractor
    "zubr.Optimizer",        ## train a reranker model
    #"before_select",
    #"zubr.FeatureSelection",
]

tree_map = {
    "s" : 0,
    "0" : 1,
    "1" : 2,
    "2" : 3,
    ## binary higher order operations
    "intersection" : 4,
    "exclude"      : 4,
    ## quantifiers
    "all"          : 5,
    "most"         : 5,
    ## aggregate
    "len"          : 6,
    "sum"          : 6,
    ### smallest 
    "smallest_one" : 7,
    "smallest"     : 7,
    ### largest
    "largest"      : 8,
    "largest_one"  : 8,
    ## high related
    "highest"      : 9,
    "lowest"       : 9,
    ## distance
    "shortest"     : 11,
    "longest"      : 11,
    ##
}

def swap_data(config):
    ebow = "%s_bow.e" % (config.atraining)
    fbow = "%s_bow.f" % (config.atraining)
    etrain = "%s.e" % (config.atraining)
    ftrain = "%s.f" % (config.atraining)
    copy(ebow,etrain)
    copy(fbow,ftrain)

def before_select(config):
    config.model_dir = config.dir 
    config.test_templates = True

    ## add
    config.train_ranks = os.path.join(config.dir,"train_ranks.txt")
    config.valid_ranks = os.path.join(config.dir,"valid_ranks.txt")

    
def make_ranklist(config):
    """Add to the rank list the tree positions, class information, etc...

    :param config: the main configuration 
    """
    rank_list = os.path.join(config.dir,"rank_list.txt")
    rank_trees = os.path.join(config.dir,"rank_list.tree")
    rank_classes = os.path.join(config.dir,"rank_list_class.txt")
    paths = os.path.join(config.dir,"paths.txt")

    ## first make rank list
    ftest     = config.atraining+"_test.f"
    fvalid    = config.atraining+"_val.f"
    ftrain    = config.atraining+".f"
    out_data  = [ftest,fvalid,ftrain]
    rank_items = {}
    graph_reps = {}

    with codecs.open(paths,encoding='utf-8') as gpaths:
        for line in gpaths:
            line = line.strip().lower()
            graph_reps[' '.join(line.split()[:-1])] = 1

    already = set()
    with codecs.open(rank_list,'w',encoding='utf-8') as my_ranks:
        for data_type in out_data:
            if not os.path.isfile(data_type): continue
            with codecs.open(data_type,encoding='utf-8') as my_file:
                for line in my_file:
                    line = line.strip().lower()
                    # if line not in graph_reps and line not in rank_items:
                    #     if 'answer' in line: print line
                    if line not in rank_items:
                        print >>my_ranks,line
                        rank_items[line] = len(rank_items)
                        already.add(line.strip().lower())

        ## add rest of the graph items (will need them just in case)
        for item in graph_reps:
            item = item.strip()
            if item.lower() not in already:
                print >>my_ranks,item
                already.add(item.lower())
                        
    ## open class file (if it exists)
    classes = {}
    if config.class_file and os.path.isfile(config.class_file):
        with codecs.open(config.class_file,encoding='utf-8') as my_classes:
            for k,line in enumerate(my_classes):
                line = line.strip()
                for item in line.split():
                    item = item.strip()
                    classes[item] = k

    tree_map2 = {}
    ## add class information and trees
    with codecs.open(rank_list,encoding='utf-8') as my_reps:
        with codecs.open(rank_classes,'w') as my_classes:
            with codecs.open(rank_trees,'w') as my_trees: 
                for line in my_reps:
                    line = line.strip()
                    print >>my_classes,' '.join([str(classes.get(t,-1)) for t in line.split()])
                    tree_positions = []
                    
                    for k,symbol in enumerate(line.split()):
                        if k == 0 and 'answer' in symbol:
                            tree_positions.append("10")
                            continue 
                        signature = re.search(r'(.+)\@(.+)',symbol)
                        stype = signature.groups()[1]
                        name = signature.groups()[0]

                        if name in tree_map:
                            tree_positions.append(str(tree_map[name]))
                        else:
                            tree_positions.append(str(tree_map[stype]))

                    assert len(tree_positions) == len(line.split())
                    print >>my_trees,"%s\t%s" % (' '.join(tree_positions),5)
                    tree_map2[line] = tree_positions

    ## map training data reps to trees
    train_tree = os.path.join(config.dir,"geoquery.tree")
    with codecs.open(train_tree,'w') as ttree:
        with codecs.open(os.path.join(config.dir,"geoquery.f")) as reps:
            for line in reps:
                line = line.strip()
                print >>ttree,"%s\t%s" % (' '.join(tree_map2[line]),5)
                    
    ## create grammar for hiero rule extractor, and annotate training data reps
    glue = """

rep -> answer pred_arg1
rep -> answer pred_arg2

## base types 

atomic_value -> 0
atomic_value -> 1
predicate_1  -> 2
predicate_2  -> 3
answer       -> 10

## special operators
binary_op    -> 4
quantifer    -> 5
aggr         -> 6
small        -> 7
large        -> 8
height       -> 9
distance     -> 11 

## one place predicate 
pred_arg1 -> predicate_1 atomic_value
pred_arg1 -> predicate_1 predicate_1 
pred_arg1 -> predicate_1 quantifier

## aggr
pred_arg1 -> aggr predicate_1
pred_arg1 -> aggr atomic_value

## 
pred_arg1 -> small predicate_1
pred_arg1 -> large predicate_1
pred_arg1 -> height predicate_1
pred_arg1 -> distance predicate_1


## two primitives 
two -> predicate_2 predicate_2
arg_arg   -> atomic_value atomic_value
pred_arg2 -> predicate_2 arg_arg
pred_arg2 -> predicate_2 pred_arg1 
pred_arg2 -> predicate_2 predicate_2
pred_arg2 -> binary_op two

    """
    grammar = os.path.join(config.dir,"grammar.txt")
    with codecs.open(grammar,'w') as my_grammar:
        print >>my_grammar,glue

    config.rfile = os.path.join(config.dir,"rank_list.txt")
    

def setup_data(config):

    ## graph data 
    geo_graph = os.path.join(geo_path,"raw_graph.att")
    new_path = os.path.join(config.dir,"modified_raw.att")
    shutil.copy(geo_graph,new_path)
    config.raw_att = geo_graph

    ## main data
    target_data = os.path.join(data_path,"geo_%s" % config.glang)
    epseudo = os.path.join(target_data,"geoquery_pseudo.e")
    fpseudo = os.path.join(target_data,"geoquery_pseudo.f")
    ebow = os.path.join(target_data,"geoquery.e")
    fbow = os.path.join(target_data,"geoquery.f")
    fnon_pseudo = os.path.join(target_data,"geoquery.f")

    ## training data
    emain = os.path.join(config.dir,"geoquery.e")
    fmain = os.path.join(config.dir,"geoquery.f")

    shutil.copy(epseudo,emain)
    shutil.copy(fpseudo,fmain)
    shutil.copy(ebow,os.path.join(config.dir,"geoquery_bow.e"))
    shutil.copy(fbow,os.path.join(config.dir,"geoquery_bow.f"))

    ## testing data
    etest = os.path.join(target_data,"geoquery_test.e")
    ftest = os.path.join(target_data,"geoquery_test.f")
    etest_mixed = os.path.join(target_data,"geoquery_test_mixed.e")
    ftest_mixed = os.path.join(target_data,"geoquery_test_mixed.f")
    if config.mixed:
        shutil.copy(etest_mixed,os.path.join(config.dir,"geoquery_test.e"))
        shutil.copy(ftest_mixed,os.path.join(config.dir,"geoquery_test.f"))
    else:
        shutil.copy(etest,config.dir)
        shutil.copy(ftest,config.dir)

    ## validation data
    evalid = os.path.join(target_data,"geoquery_val.e")
    evalid_mixed = os.path.join(target_data,"geoquery_val_mixed.e")
    fvalid_mixed = os.path.join(target_data,"geoquery_val_mixed.f")
    fvalid = os.path.join(target_data,"geoquery_val.f")
    if config.mixed: 
        shutil.copy(evalid_mixed,os.path.join(config.dir,"geoquery_val.e"))
        shutil.copy(fvalid_mixed,os.path.join(config.dir,"geoquery_val.f"))
    else:
        shutil.copy(evalid,config.dir)
        shutil.copy(fvalid,config.dir)

    ## copy over th elanguage files and set poly setting 
    if config.glang == "poly":
        vlangs = os.path.join(target_data,"geoquery_val.language")
        tlangs = os.path.join(target_data,"geoquery_test.language")
        trlangs = os.path.join(target_data,"geoquery.language")
        shutil.copy(vlangs,config.dir)
        shutil.copy(tlangs,config.dir)
        shutil.copy(trlangs,config.dir)
        
    ## set the path 
    config.atraining = os.path.join(config.dir,"geoquery")

    ## other configuration settings
    config.rmodel = 'aligner'
    config.encoding = 'utf-8'
    config.extract_phrases = True
    config.extract_hiero   = True
    #config.decode_all      = True
    config.extractor       = 'graph'
    config.eval_val        = True
    config.store_feat      = True
    config.pipeline_backup = True
    config.print_table     = True

    ## check for ranks
    train_r = os.path.join(target_data,'train_storage.npz')
    valid_r = os.path.join(target_data,'valid_storage.npz')

    if os.path.isfile(train_r) and os.path.isfile(valid_r) and not config.new_ranks:
        config.decode_data = False
        shutil.copy(train_r,config.dir)
        shutil.copy(valid_r,config.dir)
        shutil.copy(os.path.join(target_data,"train_ranks.txt"),config.dir)
        shutil.copy(os.path.join(target_data,"valid_ranks.txt"),config.dir)
        config.train_ranks = os.path.join(config.dir,"train_ranks.txt")
        config.valid_ranks = os.path.join(config.dir,"valid_ranks.txt")
    else:
        config.decode_all = True

def add_graph(config):
    config.graph = os.path.join(config.dir,"graph.att")
    if config.glang == "poly":
        config.decoder_type = "pexecutable"
    else:
        config.decoder_type = "executable"
